//+++++++++++++++++++++++++++
//Author: Thomas Androxman
//+++++++++++++++++++++++++++

//START JavaScript executable section >>>
//***************************************************************************************************************************************************

//This Example uses two canvases (one for output to WebGL and the other as a transparent overlay using Canvas2D)

//Note: Recommend using a state machine refreshed via an animation loop to help with asynchronous elements (file and image loading)
var gameState     = 1;

//Create two scene objects (one for each canvas). Note: Canvas objects can only have one context; either WebGL or Canvas2D, but not both
//Every scene object contains a default camera and a default light
var sceneGame     = new TypeScene();
var sceneOverlay  = new TypeScene();

//Create the canves painter objects. These objects actually read the geometry and translate it into WebGL or Canvas elements
var webGLrenderer = new TypeCanvasWebGLpainter (sceneGame,'GameCanvas'); 
var flatRenderer  = new TypeCanvas2Dpainter (sceneOverlay, 'OverlayCanvas',[255,255,255,0.0]); //The overlay canvas is transparent

//----------------------------------------------------------------------------------------------------------->
//Populate the first canvas (WebGL) 
//----------------------------------------------------------------------------------------------------------->

//Note: SceneObjects can contain surfaces, curves, and/or texts along with optional corresponding properties
//Note: There are three levels of properties. Scene level, SceneObject level and Piece level.
//Note: The scene level properties are auto generated and guarnteed to exist. All other properties are optional (in which case, the scene defaults take effct)

//Adding a scene object containing a line grid with a major a minor grid lines. The line-grid is a built-in method.
var gridPlane = new TypeSceneObject (); 
gridPlane.AddGrid(1,5,10,[0.6,0.6,0.6,1,1],[0.9,0.9,0.9,1,1]); //AddGrid (unitLength, unitCountX, subdivisions, color1, color2) 
sceneGame.AddObject(gridPlane); //Add the grid object to the scene
//Note: The addGrid method will auto-create two pieces (objects); one for the major grid and one for the minor. It will also auto-create correspnding color properties objects for them.
//Note: Alternatively, color1 and color2 could have been left out (which would result in them using scene default colors) or peice-properties could have been added manually.
//Note: WebGL likes colors in 0-1 range.


//Create a single composite object (containing both curve pieces and surface pieces)
//First create some curve geometry
var curve = new TypeCurve (); //The curve object itself
curve.AddVertex(new TypeXYZw(-3.0, 1.0,0.1)); //TypeXYZw is a built-in vector object with an extensive vector algebra functionality
curve.AddVertex(new TypeXYZw(-3.0, 0.0,0.1));
curve.AddVertex(new TypeXYZw(-2.0, 0.0,0.1));
curve.AddVertex(new TypeXYZw(-2.0,-1.0,0.1));
curve.AddVertex(new TypeXYZw(NaN)); //Terminate first segment
curve.AddVertex(new TypeXYZw(-3.1, 0.9,0.1));
curve.AddVertex(new TypeXYZw(-3.1,-0.1,0.1));
curve.AddVertex(new TypeXYZw(-2.1,-0.1,0.1));
curve.AddVertex(new TypeXYZw(-2.1,-0.9,0.1));
curve.AddVertex(new TypeXYZw(NaN)); //Terminate second segment
curve.AddVertex(new TypeXYZw(-3.2, 0.8,0.1));
curve.AddVertex(new TypeXYZw(-3.2,-0.2,0.1));
curve.AddVertex(new TypeXYZw(-2.2,-0.2,0.1));
curve.AddVertex(new TypeXYZw(-2.2,-0.8,0.1));
curve.SetAsInterpolated(); //Tell the engine how to interpret this pile of vertices. In this case we tell it to draw an interpolated curve that passes that passes through them
//Note: This curve object appears are three curves. A single curve object can have multiple line or curve fragments in it

//Custom properties for this curve geometry
var curveProp = new TypeCurveProperties(curve, [255,100,0,1,255,1]); //TypeCurveProperties (targetCrv,crvColor, crvThickness, crvDashPattern)
//Note: Each piece inside a sceneObject can have (optionally) its own corresponding properties
//Note: curveProp has not been linked to anything yet, we will do so in a sec
//Note: Instead of raw values, we could have passed a built-in TypeColor object for color. In this case the values will be auto converted to a color object.

//Create surface geometry 
var surf = new TypeSurface(); //The surface object itself
surf.AddVertex(new TypeXYZw(-2.8,0.1, 0.5));
surf.AddVertex(new TypeXYZw(-2.0,0.4,-0.5));
surf.AddVertex(new TypeXYZw(-1.8,1.2, 0.1));
surf.AddVertex(new TypeXYZw(-2.8,1.0, 0.1));
surf.AddMeshFace(0,1,2,3); //Tell the engine how to connect the dots (vertices) to form faces. In this case we connect vertex 0 to 1, 1 to 2, 2 to 3, and 3 to 0
//Note: no properties were assigned to this object, therefore it will pick up either sceneObject defaults (if they exists, which we didn't define yet) or scene defaults.

//Create another scene object
//Note: The order of creating sceneObjects and their pieces doesn't matter. In this case a curve and a surface object were created first and now will be added to the sceneObject we just created
var sceneObj1 = new TypeSceneObject(); //Creating a scene object to add the above curve and surface objects
sceneObj1.GetDefaultAppearance().SetColor(1.0,1.0,0.0,1.0); //We are setting color at the sceneObject level. So, all propert-less pieces inside this sceneObject will pick this color instead of the scene global default
sceneObj1.AddPiece(curve,curveProp); //Adding a piece and its properties at the same time (remember curveProp was defined earlier and it is now finally linked to a curve object)
sceneObj1.AddPiece(surf); //Adding the surface object. 
//Note: Now the sceneObj1 contains two pieces (a fragmented multi-curve with custom properties and a surface that uses sceneObj1 level properties)

//Now add the sceneObject to the scene
//Note: Only scenes are being drawn. If we create sceneObjects but never add them to the scene, they are never shown anywhere
sceneGame.AddObject(sceneObj1); 

//----------------------------------------------------------------------------------------------------------->
//Populate the second canvas (canvas2D)
//----------------------------------------------------------------------------------------------------------->
//Create a text object
var txt = new TypeText("This text is on the transparent overlay canvas");
var txtProp = new TypeTextProperties(void(0),'sans-serif',0.3); //Leave the target empty, we will assign this property to the sceneObject instead of the txt object
txt.SetPlane([-2,-2],[0,-1.6],[-2,0]); //Plane of orientation. If this plane is not planar, it will be ignored during the draw call.

//Create a scene object
var sceneObj2 = new TypeSceneObject();
sceneObj2.GetDefaultAppearance().SetTextProperties(txtProp); //Set the dfault text proprties of the sceneObject
sceneObj2.AddPiece(txt); //Add the text object to the sceneObject

//Now add the sceneObject to the scene
sceneOverlay.AddObject(sceneObj2);

//----------------------------------------------------------------------------------------------------------->
//START: Animation loop
//WebGLpainter needs to load shader files (asyncronously). As such, we need to wait for them to load using this loop
AnimationLoop();

//***************************************************************************************************************************************************
//END JavaScript executable section <<<

function AnimationLoop()
{
   requestAnimationFrame(AnimationLoop);   //register next call to self
   CheckgameState();
}
function DrawScene()
{   //All draw functionality happens here
    webGLrenderer.Draw();
    flatRenderer.Draw();
}
function CheckgameState ()
{   //State machine
    if (gameState==0) {DrawScene(); return;}
    if (gameState==1)
    {
        if (webGLrenderer && webGLrenderer.IsLoaded()) {gameState = 0; return;}
        return;
    }
}