//+++++++++++++++++++++++++++
//Author: Thomas Androxman
//+++++++++++++++++++++++++++

//START JavaScript executable section >>>
//***************************************************************************************************************************************************

var gameState     = 1;

//Create two scene objects
//Every scene object contains a default camera and a default light
var sceneGame     = new TypeScene();
var sceneOverlay  = new TypeScene();

//Create the canves painter objects
var webGLrenderer = new TypeCanvasWebGLpainter (sceneGame,'GameCanvas');
var flatRenderer  = new TypeCanvas2Dpainter (sceneOverlay, 'OverlayCanvas',[255,255,255,0.0]); //The overlay canvas is transparent

//----------------------------------------------------------------------------------------------------------->
//Populate the first canvas (WebGL) 
//----------------------------------------------------------------------------------------------------------->
//Adding a line grid 
var gridPlane = new TypeSceneObject (); 
gridPlane.AddGrid(1,5,10,[0.6,0.6,0.6,1,1],[0.9,0.9,0.9,1,1]); 
sceneGame.AddObject(gridPlane);

//Adding a single composite object (containing both curve pieces and surface pieces)
//First create some curve geometry
var curve = new TypeCurve ();
curve.AddVertex(new TypeXYZw(-3.0, 1.0,0.1));
curve.AddVertex(new TypeXYZw(-3.0, 0.0,0.1));
curve.AddVertex(new TypeXYZw(-2.0, 0.0,0.1));
curve.AddVertex(new TypeXYZw(-2.0,-1.0,0.1));
curve.AddVertex(new TypeXYZw(NaN)); //Terminate first segment
curve.AddVertex(new TypeXYZw(-3.1, 0.9,0.1));
curve.AddVertex(new TypeXYZw(-3.1,-0.1,0.1));
curve.AddVertex(new TypeXYZw(-2.1,-0.1,0.1));
curve.AddVertex(new TypeXYZw(-2.1,-0.9,0.1));
curve.AddVertex(new TypeXYZw(NaN)); //Terminate second segment
curve.AddVertex(new TypeXYZw(-3.2, 0.8,0.1));
curve.AddVertex(new TypeXYZw(-3.2,-0.2,0.1));
curve.AddVertex(new TypeXYZw(-2.2,-0.2,0.1));
curve.AddVertex(new TypeXYZw(-2.2,-0.8,0.1));
curve.SetAsInterpolated();

//Custom properties for this curve geometry
var curveProp = new TypeCurveProperties(curve, [255,100,0,1,255,1]);

//Create surface geometry (without custom properties; will use sceneObject material properties)
var surf = new TypeSurface();
surf.AddVertex(new TypeXYZw(-2.8,0.1, 0.5));
surf.AddVertex(new TypeXYZw(-2.0,0.4,-0.5));
surf.AddVertex(new TypeXYZw(-1.8,1.2, 0.1));
surf.AddVertex(new TypeXYZw(-2.8,1.0, 0.1));
surf.AddMeshFace(0,1,2,3);

//Create a scene object
var sceneObj1 = new TypeSceneObject();
sceneObj1.GetDefaultAppearance().SetColor(1.0,1.0,0.0,1.0);
sceneObj1.AddPiece(curve,curveProp);
sceneObj1.AddPiece(surf);

//Now add the sceneObject to the scene
sceneGame.AddObject(sceneObj1);

//----------------------------------------------------------------------------------------------------------->
//Populate the second canvas (canvas2D)
//----------------------------------------------------------------------------------------------------------->
//Create a text object
var txt = new TypeText("This text is on the transparent overlay canvas");
var txtProp = new TypeTextProperties(void(0),'sans-serif',0.3); //Leave the target empty, we will assign this to the sceneObject level instead of the txt object
txt.SetPlane([-2,-2],[0,-1.6],[-2,0]);

//Create a scene object
var sceneObj2 = new TypeSceneObject();
sceneObj2.GetDefaultAppearance().SetTextProperties(txtProp);
sceneObj2.AddPiece(txt);

//Now add the sceneObject to the scene
sceneOverlay.AddObject(sceneObj2);

//----------------------------------------------------------------------------------------------------------->
//START: Animation loop
//WebGLpainter needs to load shader files (asyncronously). As such, we need to wait for them to load using this loop
AnimationLoop();

//***************************************************************************************************************************************************
//END JavaScript executable section <<<

function AnimationLoop()
{
   requestAnimationFrame(AnimationLoop);   //register next call to self
   CheckgameState();
}
function DrawScene()
{
    webGLrenderer.Draw();
    flatRenderer.Draw();
}
function CheckgameState ()
{ 
    if (gameState==0) {DrawScene(); return;}
    if (gameState==1)
    {
        if (webGLrenderer && webGLrenderer.IsLoaded()) {gameState = 0; return;}
        return;
    }
}